const mongoose= require('mongoose');
mongoose.set('strictQuery', false);
mongoose.connect("mongodb+srv://ishan:123@e-commerce.ovprknx.mongodb.net/e-commerce");

