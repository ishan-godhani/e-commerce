import React from "react";

const AddProduct = () => {
    const [skuId, setSkuID] = React.useState('');
    const [name, setName] = React.useState('');
    const [price, setPrice] = React.useState('');
    const [category, setCategory] = React.useState('');
    const [company, setCompany] = React.useState('');
    const [error, serError] = React.useState(false)

    const addProduct = async () => {
        console.warn(!name)
        if (!skuId || !name || !price || !category || !company) {

            serError(true)
            return false;
        }


        console.warn(skuId, name, price, category, company)
        const userId = JSON.parse(localStorage.getItem('users'))._id;
        let result = await fetch("http://localhost:5000/add-product", {
            method: "post",
            body: JSON.stringify({ skuId, name, price, category, company, userId }),
            headers: {
                'Content-Type': 'application/json',
                authorization: `bearer ${JSON.parse(localStorage.getItem('token'))}`
            
            }
        });
        result = await result.json();
        console.warn(result)
    }

    return (
        <div className="product">
            <h1> Add Product </h1>
            <input className="inputbox" type="text" value={skuId} onChange={(e) => setSkuID(e.target.value)} placeholder="Enter SKU ID" />
            {error && !skuId && <span className="invalid-input">Enter Valid SKU ID</span>}
            <input className="inputbox" type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter  Product Name" />
            {error && !name && <span className="invalid-input">Enter Valid Product</span>}
            <input className="inputbox" type="text" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="Enter Price" />
            {error && !price && <span className="invalid-input">Enter Valid Price</span>}
            <input className="inputbox" type="text" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Enter Category Name" />
            {error && !category && <span className="invalid-input">Enter Valid Category</span>}
            <input className="inputbox" type="text" value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Enter Brand Name" />
            {error && !company && <span className="invalid-input">Enter Valid Brand</span>}
            <button onClick={addProduct} className="appButton" type="button">Add Product</button>
        </div>
    )
}

export default AddProduct;

